﻿using Contacts.Data;
using Contacts.Helpers;
using Contacts.Service;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace Contacts.Controllers
{
    [Route("contacts")]
    [Produces("application/json")]

    public class ContactsController : ControllerBase
    {
        private ContactsQueries _contactsQueries;

        public ContactsController(ContactsQueries contactsQueries)
        {
            _contactsQueries = contactsQueries;
        }

        [HttpGet]
        [Route("getcontactlist")]
        [ProducesResponseType((int)HttpStatusCode.OK, Type = typeof(List<Contact>))]
        public async Task<IActionResult> SearchContacts()
        {            
            var contactsResult = await _contactsQueries.GetContacts();

            return Ok(contactsResult);
        }

        [HttpGet]
        [Route("getcontactbyid")]
        [ProducesResponseType((int)HttpStatusCode.OK, Type = typeof(Contact))]
        public async Task<IActionResult> ContactById(int id)
        {
            var contactResult = await _contactsQueries.GetContactById(id);

            if(contactResult == null)
            {
                return Ok("no matching contact found");
            }
            return Ok(contactResult);
        }

        [HttpPost]
        [Route("updatecontact")]
        [ProducesResponseType((int)HttpStatusCode.OK, Type = typeof(bool))]
        public async Task<IActionResult> UpdateContact(Contact contact)
        {
            if(Validate.ValidateUpdateRequest(contact) == false)
            {
                return BadRequest();
            }

            if (!await _contactsQueries.CheckContactExists(contact.Id)) return Ok("No contact exists for the entered contact Id");
            
            var contactResult = await _contactsQueries.UpdateContact(contact);
            
            if (contactResult == false)
            {
                return Ok("Error encountered. Please try again. If the error persists please check the source file has data and is correctly formatted");
            }
            return Ok(contactResult);
        }

        [HttpPost]
        [Route("addcontact")]
        [ProducesResponseType((int)HttpStatusCode.OK, Type = typeof(bool))]
        public async Task<IActionResult> AddContact(Contact contact)
        {
            if (await _contactsQueries.CheckContactExists(contact.Id)) return Ok("A contact aready exists for the entered contact Id");

            if (Validate.ValidateAddRequest(contact) == false)
            {
                return BadRequest();
            }
            var contactResult = await _contactsQueries.AddNewContact(contact);

            return Ok(contactResult);
        }

        [HttpPost]
        [Route("deletecontact")]
        [ProducesResponseType((int)HttpStatusCode.OK, Type = typeof(bool))]
        public async Task<IActionResult> DeleteContact(int contactId)
        {
            if (Validate.ValidateDeleteRequest(contactId) == false)
            {
                return BadRequest();
            }
            if (!await _contactsQueries.CheckContactExists(contactId)) return Ok("No contact exists for the entered contact Id");

            var contactResult = await _contactsQueries.DeleteContact(contactId);

            return Ok(contactResult);
        }

    }
}
