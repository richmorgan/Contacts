﻿namespace Contacts.Data
{
    internal class myAppSettings
    {
        public string SourceFile { get; set; }    
    }
}
