﻿using Contacts.Data;

namespace Contacts.Helpers
{
    public static class Validate
    {
        public static bool ValidateUpdateRequest(Contact contact)
        {
            if (contact.Id <= 0)
            {
                return false;
            }
            else if (contact.Name.Trim().Length == 0 || contact.Email.Trim().Length == 0 || contact.Phone.Trim().Length == 0 || (!contact.Email.Contains("@")))
            {
                return false;
            }
            return true;
        }

        public static bool ValidateAddRequest(Contact contact)
        {
            if (contact.Id <= 0)
            {
                return false;
            }
            else if (contact.Name.Trim().Length == 0 || contact.Email.Trim().Length == 0 || contact.Phone.Trim().Length == 0)
            {
                return false;
            }
            return true;
        }

        public static bool ValidateDeleteRequest(int  contactId)
        {
            if (contactId <= 0)
            {
                return false;
            }
            return true;
        }

    }
}
