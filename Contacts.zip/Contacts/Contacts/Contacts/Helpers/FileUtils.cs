﻿using Contacts.Data;
using Newtonsoft.Json;

namespace Contacts.Helpers
{
    public class FileUtils: IFileUtils
    {
        private IConfiguration _config;

        public FileUtils(IConfiguration config)
        {
            _config = config;
        }

        public FileInfo FindFile(string fileName)
        {
            string startPath = Path.Combine(Environment.CurrentDirectory, fileName);
            FileInfo file = new FileInfo(startPath);
            while (!file.Exists)
            {
                if (file.Directory.Parent == null)
                {
                    return null;
                }
                DirectoryInfo parentDir = file.Directory.Parent;
                file = new FileInfo(Path.Combine(parentDir.FullName, file.Name));
            }
            return file;
        }

        public string GetContactsFromFile()
        {
            string filePath = FindFile(_config.GetValue<string>("SourceFile")).ToString();
            string json = File.ReadAllText(filePath);

            return json;
        }

        public bool SaveContactsToFile(List<Contact> contactsList)
        {
            try
            {
                string filePath = FindFile(_config.GetValue<string>("SourceFile")).ToString();

                string serialisedJson = JsonConvert.SerializeObject(contactsList, Formatting.Indented);
                using (var sw = new StreamWriter(filePath))
                    sw.Write(JsonConvert.SerializeObject(contactsList));

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

    }

    public interface IFileUtils
    {
        FileInfo FindFile(string fileName);    
        bool SaveContactsToFile(List<Contact> contactsList);
        string GetContactsFromFile();
    }
    
}
