﻿using Contacts.Data;
using Contacts.Helpers;
using Moq;
using Xunit;
using Microsoft.Extensions.Options;
using Contacts.Service;

namespace Contacts.Tests
{
    public class ContactsTests
    {
        public Mock<FileUtils> _mockFileUtils { get; set; }

        public ContactsTests()
        {
           _mockFileUtils = new Mock<FileUtils>();
        }

        [Fact]
        public void ValidateUpdateRequest_Returns_True_With_Valid_Request()
        {
            var testRequest = new Contact
            {
                Id = 99,
                Name = "Fran Flander",
                Email = "abc@abc.com",
                Phone = "01234123123"
            };

            var result = Validate.ValidateUpdateRequest(testRequest);

            Assert.True(result);    
        }

        [Fact]
        public void ValidateUpdateRequest_Returns_False_With_Invalid_Request()
        {
            var testRequest = new Contact
            {
                Id = -1,
                Name = "Fran Flander",
                Email = "abc-abc.com",
                Phone = ""
            };

            var result = Validate.ValidateUpdateRequest(testRequest);

            Assert.False(result);
        }

        [Fact]
        public void ContactQueries_CheckContactExists_Returns_True_With_Correct_Data()
        {                       
            var testRequest = new Contact
            {
                Id = 1,
                Name = "Fran Flander",
                Email = "abc-abc.com",
                Phone = ""
            };

            IConfiguration config = new ConfigurationBuilder().AddJsonFile("appsettings.Development.json").Build();
            MockFileUtils mockFileUtils = new MockFileUtils(config);

            ContactsQueries contactsQueries = new ContactsQueries(config, mockFileUtils);

            var result = contactsQueries.CheckContactExists(testRequest.Id);
            Assert.True(result.Result);    
        }

        [Fact]
        public void ContactQueries_CheckContactExists_Returns_False_With_Incorrect_Data()
        {
            var testRequest = new Contact
            {
                Id = -1,
                Name = "Fran Ling",
                Email = "abc-abc.com",
                Phone = ""
            };

            IConfiguration config = new ConfigurationBuilder().AddJsonFile("appsettings.Development.json").Build();
            MockFileUtils mockFileUtils = new MockFileUtils(config);

            ContactsQueries contactsQueries = new ContactsQueries(config, mockFileUtils);

            var result = contactsQueries.CheckContactExists(testRequest.Id);
            Assert.False(result.Result);
        }

    }

    public class MockFileUtils : FileUtils
    {
        public MockFileUtils(IConfiguration config) : base(config)
        {
        }

        public string GetContactsFromFile()
        {
            string testResponse = "[{\"Id\":1,\"Name\":\"Alan Herring\",\"Email\":\"alanherring@unq.com\",\"Phone\":\"019134972020\"},{\"Id\":2,\"Name\":\"Kai Kipper\",\"Email\":\"kaikipper@unq.com\",\"Phone\":\"019514722967\"},{\"Id\":3,\"Name\":\"Alison Cod\",\"Email\":\"alisoncod@unq.com\",\"Phone\":\"018874782693\"},{\"Id\":4,\"Name\":\"Scott Sturgeon\",\"Email\":\"scottsturgeon@unq.com\",\"Phone\":\"018625813022\"},{\"Id\":5,\"Name\":\"Mary Haddock\",\"Email\":\"marylouhaddock@unq.com\",\"Phone\":\"019965202967\"},{\"Id\":6,\"Name\":\"Lars Angel\",\"Email\":\"larsonangel@unq.com\",\"Phone\":\"019725662684\"},{\"Id\":7,\"Name\":\"Shelby Hake\",\"Email\":\"shelbyballard@unq.com\",\"Phone\":\"018244673579\"},{\"Id\":8,\"Name\":\"Lea Trout\",\"Email\":\"leatrout@unq.com\",\"Phone\":\"018995283402\"},{\"Id\":9,\"Name\":\"Cecelia Salmon\",\"Email\":\"ceceliasalmon@unq.com\",\"Phone\":\"018625073140\"},{\"Id\":10,\"Name\":\"Melvin Guppy\",\"Email\":\"melvinguppy@unq.com\",\"Phone\":\"019014443081\"},{\"Id\":11,\"Name\":\"Feargal Sharky\",\"Email\":\"feargalsharky@unq.com\",\"Phone\":\"018315393366\"},{\"Id\":12,\"Name\":\"Wendi Carp\",\"Email\":\"wendicarp@unq.com\",\"Phone\":\"018684142720\"},{\"Id\":13,\"Name\":\"Wally Flounder\",\"Email\":\"wallyflounder@unq.com\",\"Phone\":\"018145583191\"},{\"Id\":14,\"Name\":\"Howell Bass\",\"Email\":\"howellbass@unq.com\",\"Phone\":\"019265123631\"},{\"Id\":15,\"Name\":\"Nguyen Krill\",\"Email\":\"nguyenkrill@unq.com\",\"Phone\":\"018384692152\"},{\"Id\":16,\"Name\":\"Norris Perch\",\"Email\":\"norrisperch@unq.com\",\"Phone\":\"018185632900\"},{\"Id\":17,\"Name\":\"Salinas Pollock\",\"Email\":\"salinaspollock@unq.com\",\"Phone\":\"018884133775\"},{\"Id\":18,\"Name\":\"Michelle Scallop\",\"Email\":\"michellescallop@unq.com\",\"Phone\":\"019884462594\"},{\"Id\":19,\"Name\":\"Polly Pike\",\"Email\":\"ppike@unq.com\",\"Phone\":\"019654922552\"},{\"Id\":20,\"Name\":\"Rosie Frye\",\"Email\":\"rosieFrye@unq.com\",\"Phone\":\"018454562237\"}]";

            return testResponse;
        }
    }

}
