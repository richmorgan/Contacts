﻿using Contacts.Data;
using Contacts.Helpers;
using Newtonsoft.Json;

namespace Contacts.Service
{
    public class ContactsQueries : IContactsQueries
    {
        private IConfiguration _config;
        private FileUtils _fileUtils { get; set; }

        public ContactsQueries(IConfiguration config, FileUtils fileUtils)
        {
            _config = config;
            _fileUtils = fileUtils;             
        }

        public async Task<List<Contact>> GetContacts()
        {
            List<Contact> contacts = GetContactsFromFile();

            return await Task.FromResult(contacts);
        }

        public async Task<bool> CheckContactExists(int contactId)
        {
            bool res = ContactExists(contactId);

            return await Task.FromResult(res);
        }

        public async Task<Contact> GetContactById(int id)
        {
            Contact contact = GetSingleContactById(id);

            return await Task.FromResult(contact);
        }

        public async Task<bool> UpdateContact(Contact contact)
        {
            bool res = UpdateSingleContact(contact);
                
            return await Task.FromResult(res);            
        }
       
        public async Task<bool> AddNewContact(Contact contact)
        {
            bool res = AddSingleContact(contact);

            return await Task.FromResult(res);
        }

        public async Task<bool> DeleteContact(int id)
        {
            bool res = DeleteContactById(id);

            return await Task.FromResult(res);
        }


        private bool ContactExists(int id)
        {
            try
            {
                var json = _fileUtils.GetContactsFromFile();
                List<Contact> contactsList = GetContactsList(json);
                Contact? con = GetContactFromList(contactsList, id);
            
                return con != null; 
            }
            catch(Exception ex)
            {
                return false;
            }
        }

         private List<Contact> GetContactsFromFile()
         {
            try
            {
                string json = _fileUtils.GetContactsFromFile();
                List<Contact> contactsList = GetContactsList(json);
                return contactsList;               
            }
            catch (Exception ex)
            {
                return null;
            }
         }

        private bool AddSingleContact(Contact contact)
        {
            try
            {
                var json = _fileUtils.GetContactsFromFile();
                List<Contact> contactsList = GetContactsList(json);
                contactsList.Add(contact);
                bool res = _fileUtils.SaveContactsToFile(contactsList);

                return res;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private bool DeleteContactById(int id)
        {
            try
            {
                var json = _fileUtils.GetContactsFromFile();
                List<Contact> contactsList = GetContactsList(json);
                Contact? con = GetContactFromList(contactsList, id);

                contactsList.Remove(con);
                
                bool res = _fileUtils.SaveContactsToFile(contactsList);

                return res;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private Contact? GetSingleContactById(int id)
        {
            try
            {
                var json = _fileUtils.GetContactsFromFile();
                               
                List<Contact> contactsList = GetContactsList(json);
                Contact? con = GetContactFromList(contactsList, id);    

                return con;                
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        private bool UpdateSingleContact(Contact contact)
        {
            try
            {
                var json = _fileUtils.GetContactsFromFile();
                List<Contact> contactsList = GetContactsList(json);
                Contact? con = GetContactFromList(contactsList, contact.Id);
                if (con == null)  //not found
                {
                    return false;
                }
                con.Name = contact.Name;
                con.Email = contact.Email;  
                con.Phone = contact.Phone;  

                bool res = _fileUtils.SaveContactsToFile(contactsList);

                return res;
            }
            catch (Exception ex)
            {
                return false;
            }            
        }

        private List<Contact>?GetContactsList(string json)
        {
            List<Contact> contactsList = JsonConvert.DeserializeObject<List<Contact>>(json);
            return contactsList;
        }
        
        private Contact GetContactFromList(List<Contact> contactsList, int id)
        {
            Contact? con = contactsList?.FirstOrDefault(s => s?.Id == id);

            return con;
        }
        
    }

    public interface IContactsQueries
    {
        public Task<List<Contact>> GetContacts();
        public Task<Contact> GetContactById(int id);
        public Task<bool> UpdateContact(Contact contact);
        public Task<bool> DeleteContact(int id);
        public Task<bool> AddNewContact(Contact contact);
        public Task<bool> CheckContactExists(int contactId);
    }

    public class UsersResponse
    {
        public List<Contact>? Data { get; set; }
    }

}